#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int read_input(const char*, float**, float**); 
void vis(float*, int); 
float* multiply(float*, float*, int); 
void sum(float*, float*, int); 
int write_output(char*, const float*, int); 
